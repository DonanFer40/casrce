"""Configuración central de permisos."""
