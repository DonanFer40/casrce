
document.addEventListener("DOMContentLoaded", () => {

    const formulario_busqueda = document.getElementById("formulario_busqueda");
    const select_nacionalidad = document.getElementById("nacionalidad");
    const input_cedula_identidad = document.getElementById("cedula_identidad");
    const mensaje_cedula = document.getElementById("mensaje_cedula_identidad");

    const btn_agregar_perfil = document.getElementById("btn_agregar_perfil");
    const btn_limpiar_controles = document.getElementById("btn_limpiar_controles");

    const input_nombres_usuario = document.getElementById("nombres_usuario");
    const input_apellidos_usuario = document.getElementById("apellidos_usuario");
    const input_ci_usuario_visualizar = document.getElementById("ci_usuario_visualizar");

    const dialogo_registrar = document.getElementById("dialogo_registrar");
    const cerrar_dialogo_registrar = document.getElementById("cerrar_dialogo_registrar");

    const input_rol_seleccionado = document.getElementById("rol_seleccionado");
    const input_perfil_seleccionado = document.getElementById("perfil_seleccionado");
    const input_estado_perfil_seleccionado = document.getElementById("estado_perfil_seleccionado");
    const formulario_registrar = document.getElementById("formulario_registrar");
    const contenedor_nuevo_perfiles = document.getElementById("contenedor_nuevo_perfiles");

    const contenedor_pnfs = document.getElementById("contenedor_pnfs");

    const dialogo_actualizar = document.getElementById("dialogo_actualizar");
    const cerrar_dialogo_actualizar = document.getElementById("cerrar_dialogo_actualizar");

    const formulario_actualizar = document.getElementById("formulario_actualizar");

    const input_habilitar_perfil = document.getElementById("habilitar_perfil");
    const input_deshabilitar_perfil = document.getElementById("deshabilitar_perfil");

    const contenedor_perfiles = document.getElementById("contenedor_perfiles");

    // =========================================================
    // CONFIGURACIÓN DE CÉDULA
    // =========================================================

    configurarCedula(select_nacionalidad, input_cedula_identidad);

    // Evitar mensajes emergentes del navegador.
    // La validación se mostrará debajo del input.
    formulario_busqueda.noValidate = true;

    // =========================================================
    // VALIDACIÓN VISUAL DE CÉDULA
    // =========================================================

    function mostrarEstadoCedula(estado, texto) {

        if (mensaje_cedula) {
            mensaje_cedula.textContent = texto;
            mensaje_cedula.className = estado;
        }

        input_cedula_identidad.classList.remove(
            "is-valid",
            "is-invalid"
        );

        if (estado === "estado-correcto") {
            input_cedula_identidad.classList.add("is-valid");
        }

        if (estado === "estado-error") {
            input_cedula_identidad.classList.add("is-invalid");
        }
    }

    function validarCedulaPersonal() {

        const nacionalidad = select_nacionalidad.value;
        const cedula = input_cedula_identidad.value.trim();

        input_cedula_identidad.setCustomValidity("");

        // Nacionalidad no seleccionada.
        if (!nacionalidad) {

            input_cedula_identidad.setCustomValidity(
                "Seleccione la nacionalidad."
            );

            mostrarEstadoCedula(
                "estado-pendiente",
                "Seleccione nacionalidad."
            );

            return false;
        }

        // Documento vacío.
        if (!cedula) {

            input_cedula_identidad.setCustomValidity(
                "Ingrese el documento de identidad."
            );

            mostrarEstadoCedula(
                "estado-pendiente",
                "Ingrese su documento."
            );

            return false;
        }

        // Comprobar que solamente contenga números.
        if (!/^\d+$/.test(cedula)) {

            input_cedula_identidad.setCustomValidity(
                "El documento debe contener solamente números."
            );

            mostrarEstadoCedula(
                "estado-error",
                "Solo números."
            );

            return false;
        }

        // Comprobar longitud según nacionalidad.
        let longitudValida = false;

        if (nacionalidad === "V") {
            longitudValida =
                cedula.length >= 7 && cedula.length <= 8;
        }

        if (nacionalidad === "E") {
            longitudValida =
                cedula.length >= 8 && cedula.length <= 10;
        }

        if (!longitudValida) {

            input_cedula_identidad.setCustomValidity(
                "La longitud del documento no es válida."
            );

            mostrarEstadoCedula(
                "estado-error",
                "Longitud no válida."
            );

            return false;
        }

        // Documento válido.
        input_cedula_identidad.setCustomValidity("");

        mostrarEstadoCedula(
            "estado-correcto",
            "Documento válido."
        );

        return true;
    }

    // =========================================================
    // VALIDAR MIENTRAS SE ESCRIBE
    // =========================================================

    input_cedula_identidad.addEventListener("input", () => {

        // Permitir únicamente números.
        const valorLimpio = input_cedula_identidad.value.replace(/\D/g, "");

        if (input_cedula_identidad.value !== valorLimpio) {
            input_cedula_identidad.value = valorLimpio;
        }

        validarCedulaPersonal();

    });

    // Al cambiar nacionalidad, configurarCedula()
    // limpia el documento y actualiza el mensaje pendiente.
    select_nacionalidad.addEventListener("change", () => {

        input_cedula_identidad.setCustomValidity("");

        input_cedula_identidad.classList.remove(
            "is-valid",
            "is-invalid"
        );

        if (select_nacionalidad.value === "") {

            mostrarEstadoCedula(
                "estado-pendiente",
                "Seleccione nacionalidad."
            );

        } else {

            mostrarEstadoCedula(
                "estado-pendiente",
                "Ingrese su documento."
            );

        }

    });

    // =========================================================
    // RESTABLECER ESTADO VISUAL DE CÉDULA
    // =========================================================

    function restablecerEstadoCedula() {

        input_cedula_identidad.value = "";

        input_cedula_identidad.setCustomValidity("");

        input_cedula_identidad.classList.remove(
            "is-valid",
            "is-invalid"
        );

        if (select_nacionalidad.value === "") {

            mostrarEstadoCedula(
                "estado-pendiente",
                "Seleccione nacionalidad."
            );

        } else {

            mostrarEstadoCedula(
                "estado-pendiente",
                "Ingrese su documento."
            );

        }
    }

    // =========================================================
    // OBTENER COOKIE CSRF
    // =========================================================

    function getCookie(nombre) {

        let cookieValue = null;

        if (document.cookie && document.cookie !== "") {

            const cookies = document.cookie.split(";");

            for (let cookie of cookies) {

                cookie = cookie.trim();

                if (cookie.startsWith(nombre + "=")) {

                    cookieValue = decodeURIComponent(
                        cookie.substring(nombre.length + 1)
                    );

                    break;
                }
            }
        }

        return cookieValue;
    }

    // =========================================================
    // BUSCAR PERSONAL
    // =========================================================

    formulario_busqueda.addEventListener("submit", async (e) => {

        e.preventDefault();

        if (!validarCedulaPersonal()) {
            return;
        }

        try {

            const formulario = new FormData(formulario_busqueda);

            const respuesta = await fetch("/bus_per_asig/", {
                method: "POST",
                headers: {
                    "X-CSRFToken": getCookie("csrftoken")
                },
                body: formulario
            });

            const resultado = await respuesta.json();

            console.log(resultado);

            if (resultado.estado == "fallo") {

                await NotificacionesCASRCE.mostrar({
                    title: resultado.title,
                    text: resultado.descripcion,
                    icon: resultado.icon,
                    allowOutsideClick: false,
                    allowEscapeKey: false
                });

                return;
            }

            await NotificacionesCASRCE.mostrar({
                title: "Exito",
                text: "Se encontro los datos del usuario.",
                icon: "success",
                allowOutsideClick: false,
                allowEscapeKey: false
            });

            btn_agregar_perfil.disabled = false;

            input_nombres_usuario.value = resultado.usuario.nombres;
            input_apellidos_usuario.value = resultado.usuario.apellidos;

            input_ci_usuario_visualizar.value = resultado.usuario.cedula;

            contenedor_perfiles.innerHTML = "";

            if (resultado.perfiles && resultado.perfiles.length > 0) {

                resultado.perfiles.forEach((perfil, index) => {

                    const fila = document.createElement("tr");

                    fila.dataset.idPerfil = perfil.id_perfil;
                    fila.dataset.rol = perfil.rol;

                    fila.innerHTML = `
                        <td>${index + 1}</td>
                        <td>${perfil.rol}</td>
                        <td>${perfil.pnf}</td>
                        <td>${perfil.nucleo}</td>
                        <td>${perfil.estado}</td>
                    `;

                    contenedor_perfiles.appendChild(fila);

                });

            } else {

                const fila = document.createElement("tr");

                fila.innerHTML = `
                    <td colspan="5" class="sin_perfiles">
                        No hay perfiles registrados para este usuario.
                    </td>
                `;

                contenedor_perfiles.appendChild(fila);
            }

        } catch (error) {

            console.error(error);

        }
    });

    // =========================================================
    // SELECCIONAR PERFIL REGISTRADO
    // =========================================================

    contenedor_perfiles.addEventListener("click", async (e) => {

        const fila = e.target.closest("tr");

        if (!fila || !fila.dataset.rol) return;

        const rol = fila.dataset.rol;
        const idPerfil = fila.dataset.idPerfil;

        try {

            const formulario = new FormData();

            formulario.append("rol", rol);

            const respuesta = await fetch("/info_per_asig/", {
                method: "POST",
                headers: {
                    "X-CSRFToken": getCookie("csrftoken")
                },
                body: formulario
            });

            const resultado = await respuesta.json();

            console.log(resultado);

            if (resultado.estado !== "exito") {

                await NotificacionesCASRCE.mostrar({
                    icon: resultado.icon,
                    title: resultado.title,
                    text: resultado.descripcion
                });

                return;
            }

            input_rol_seleccionado.value = rol;
            input_perfil_seleccionado.value = idPerfil;

            input_estado_perfil_seleccionado.value = resultado.activo;

            input_habilitar_perfil.checked = false;
            input_deshabilitar_perfil.checked = false;

            if (resultado.activo === true) {

                input_habilitar_perfil.checked = true;

            } else if (resultado.activo === false) {

                input_deshabilitar_perfil.checked = true;

            }

            contenedor_pnfs.innerHTML = "";

            const pnfsAsignados = new Set(
                (resultado.pnfs_asignados || []).map(
                    pnf => String(pnf.id_pnf)
                )
            );

            const pnfsDisponibles = resultado.pnfs_disponibles || [];

            pnfsDisponibles.forEach((pnf) => {

                const idPnf = String(pnf.id_pnf);

                const asignado = pnfsAsignados.has(idPnf);

                const contenedor = document.createElement("div");

                contenedor.classList.add("pnf_opcion");

                contenedor.innerHTML = `
                    <label>
                        <input
                            type="radio"
                            name="pnf"
                            value="${pnf.id_pnf}"
                            ${asignado ? "checked" : ""}
                        >
                        <span>${pnf.pnf}</span>
                        <small>${pnf.codigo}</small>
                    </label>
                `;

                contenedor_pnfs.appendChild(contenedor);

            });

            if (pnfsDisponibles.length === 0) {

                contenedor_pnfs.innerHTML = `
                    <div class="sin_pnfs">
                        No hay PNF disponibles para asignar.
                    </div>
                `;

            }

            dialogo_actualizar.showModal();

        } catch (error) {

            console.error(error);

        }
    });

    // =========================================================
    // ACTUALIZAR PERFIL
    // =========================================================

    formulario_actualizar.addEventListener("submit", async (e) => {

        e.preventDefault();

        const perfilActivo = input_habilitar_perfil.checked;

        input_estado_perfil_seleccionado.value =
            perfilActivo ? "true" : "false";

        if (
            !input_habilitar_perfil.checked &&
            !input_deshabilitar_perfil.checked
        ) {
            await NotificacionesCASRCE.mostrar({
                icon: "warning",
                title: "Estado no seleccionado",
                text: "Debe seleccionar el estado del perfil."
            });

            return;
        }

        try {

            const formulario = new FormData(formulario_actualizar);

            console.log("ROL:", formulario.get("rol"));
            console.log("ID PERFIL:", formulario.get("id_perfil"));
            console.log("ESTADO:", formulario.get("estado_perfil"));

            const respuesta = await fetch("/act_per_reg/", {
                method: "POST",
                headers: {
                    "X-CSRFToken": getCookie("csrftoken")
                },
                body: formulario
            });

            const resultado = await respuesta.json();

            console.log(resultado);

            dialogo_actualizar.close();

            await NotificacionesCASRCE.mostrar({
                title: resultado.title,
                text: resultado.descripcion,
                icon: resultado.icon,
                allowOutsideClick: false,
                allowEscapeKey: false
            });

            if (resultado.estado === "exito") {

                await perfiles_registrados();

            }

        } catch (error) {

            console.error(error);

        }
    });

    cerrar_dialogo_actualizar.addEventListener("click", () => {

        dialogo_actualizar.close();

    });

    // =========================================================
    // AGREGAR NUEVO PERFIL
    // =========================================================

    btn_agregar_perfil.addEventListener("click", async () => {

        try {

            const respuesta = await fetch("/per_dis_asi/");

            const resultado = await respuesta.json();

            if (resultado.estado !== "exito") {

                NotificacionesCASRCE.mostrar({
                    icon: resultado.icon,
                    title: resultado.title,
                    text: resultado.descripcion
                });

                return;
            }

            contenedor_nuevo_perfiles.innerHTML = "";

            if (!resultado.perfiles?.length) {

                contenedor_nuevo_perfiles.innerHTML = `
                    <p class="mensaje_sin_perfiles">
                        No existen perfiles disponibles para asignar
                        en el núcleo ${resultado.nucleo.municipio}.
                    </p>
                `;

                dialogo_registrar.showModal();

                return;
            }

            resultado.perfiles.forEach((perfil) => {

                const contenedor = document.createElement("div");

                contenedor.className = "perfil_disponible";

                const clavePerfil = {
                    "Docente": "docente",
                    "Coordinador de PNF": "coordinador_pnf",
                    "Encargado de Control de Estudio": "control_estudio"
                }[perfil.rol];

                const idPerfil = `perfil_${clavePerfil}`;

                contenedor.innerHTML = `
                    <label class="checkbox_pnf perfil_principal">
                        <input
                            type="checkbox"
                            name="perfiles"
                            value="${perfil.rol}"
                            id="${idPerfil}"
                        >

                        <span>${perfil.rol}</span>
                    </label>
                `;

                // PNF DEL PERFIL
                if (perfil.pnfs?.length) {

                    const contenedorPnfs = document.createElement("div");

                    contenedorPnfs.className = "contenedor_pnfs_disponibles";

                    contenedorPnfs.hidden = true;

                    contenedorPnfs.innerHTML = `
                        <p class="titulo_pnf">
                            PNF disponibles en ${resultado.nucleo.municipio}
                        </p>

                        <div class="lista_checkbox_pnf"></div>
                    `;

                    const listaPnfs = contenedorPnfs.querySelector(
                        ".lista_checkbox_pnf"
                    );

                    perfil.pnfs.forEach((pnf) => {

                        const etiqueta = document.createElement("label");

                        etiqueta.className = "checkbox_pnf";

                        etiqueta.innerHTML = `
                            <input
                                type="checkbox"
                                name="pnfs_${clavePerfil}"
                                value="${pnf.id_pnf}"
                            >

                            <span>
                                ${pnf.id_pnf__pnf}
                                <small>
                                    (${pnf.id_pnf__codigo})
                                </small>
                            </span>
                        `;

                        listaPnfs.appendChild(etiqueta);

                    });

                    contenedor.appendChild(contenedorPnfs);

                    // MOSTRAR / OCULTAR PNF
                    const checkboxPerfil = contenedor.querySelector(
                        `#${idPerfil}`
                    );

                    checkboxPerfil.addEventListener("change", () => {

                        if (checkboxPerfil.checked) {

                            contenedorPnfs.hidden = false;

                        } else {

                            contenedorPnfs.hidden = true;

                            contenedorPnfs.querySelectorAll(
                                'input[type="checkbox"]'
                            ).forEach((checkbox) => {

                                checkbox.checked = false;

                            });

                        }

                    });
                }

                contenedor_nuevo_perfiles.appendChild(contenedor);

            });

            dialogo_registrar.showModal();

        } catch (error) {

            console.error(error);

        }
    });

    cerrar_dialogo_registrar.addEventListener("click", () => {

        dialogo_registrar.close();

    });

    // =========================================================
    // REGISTRAR NUEVOS PERFILES
    // =========================================================

    formulario_registrar.addEventListener("submit", async (e) => {

        e.preventDefault();

        try {

            const formulario = new FormData(formulario_registrar);

            if (!formulario.getAll("perfiles").length) {

                NotificacionesCASRCE.mostrar({
                    icon: "warning",
                    title: "Perfil no seleccionado",
                    text: "Debe seleccionar al menos un perfil."
                });

                return;
            }

            const respuesta = await fetch("/agr_per_asig/", {
                method: "POST",
                headers: {
                    "X-CSRFToken": getCookie("csrftoken")
                },
                body: formulario
            });

            const resultado = await respuesta.json();

            console.log(resultado);

            dialogo_registrar.close();

            await perfiles_registrados();

            await NotificacionesCASRCE.mostrar({
                title: resultado.title,
                text: resultado.descripcion,
                icon: resultado.icon,
                allowOutsideClick: false,
                allowEscapeKey: false
            });

        } catch (error) {

            console.error(error);

        }
    });

    // =========================================================
    // LIMPIAR CONTROLES
    // =========================================================

    async function limpiar_controles() {

        try {

            const respuesta = await fetch("/eli_var_sec/");

            const resultado = await respuesta.json();

            console.log(resultado);

            input_nombres_usuario.value = "";
            input_apellidos_usuario.value = "";
            input_ci_usuario_visualizar.value = "";

            // Limpiar documento y restablecer su estado visual.
            restablecerEstadoCedula();

            contenedor_perfiles.innerHTML = "";

            btn_agregar_perfil.disabled = true;

        } catch (error) {

            console.error(error);

        }
    }

    btn_limpiar_controles.addEventListener("click", async () => {

        await limpiar_controles();

    });

    window.addEventListener("load", async () => {

        await limpiar_controles();

    });

    // =========================================================
    // CONSULTAR PERFILES REGISTRADOS
    // =========================================================

    async function perfiles_registrados() {

        try {

            const respuesta = await fetch("/per_reg/");

            const resultado = await respuesta.json();

            console.log(resultado);

            if (resultado.estado === "fallo") {

                await NotificacionesCASRCE.mostrar({
                    title: resultado.title,
                    text: resultado.descripcion,
                    icon: resultado.icon,
                    allowOutsideClick: false,
                    allowEscapeKey: false
                });

                return;
            }

            contenedor_perfiles.innerHTML = "";

            if (!resultado.perfiles || resultado.perfiles.length === 0) {

                const fila = document.createElement("tr");

                fila.innerHTML = `
                    <td colspan="5" class="sin_perfiles">
                        No hay perfiles registrados.
                    </td>
                `;

                contenedor_perfiles.appendChild(fila);

                return;
            }

            resultado.perfiles.forEach((perfil, index) => {

                const fila = document.createElement("tr");

                fila.dataset.idPerfil = perfil.id_perfil;
                fila.dataset.rol = perfil.rol;

                console.log(fila.dataset.idPerfil);

                fila.innerHTML = `
                    <td>
                        ${index + 1}
                    </td>

                    <td>
                        ${perfil.rol}
                    </td>

                    <td>
                        ${perfil.pnf
                        ? perfil.pnf.nombre
                        : "NO CUENTA CON P.N.F"
                    }
                    </td>

                    <td>
                        ${perfil.nucleo
                        ? perfil.nucleo.municipio
                        : "NO CUENTA CON NÚCLEO"
                    }
                    </td>

                    <td>
                        ${perfil.estado}
                    </td>
                `;

                contenedor_perfiles.appendChild(fila);

            });

        } catch (error) {

            console.error(error);

        }
    }

    // Cargar perfiles al iniciar.
    perfiles_registrados();

});
